# Neon Street Racer — installable web game

This ZIP contains a playable touch-friendly 2D arcade racer with traffic, score, best score, nitro and restart.

## Android-only setup using GitHub Pages
1. Download and extract this ZIP on your phone.
2. In Chrome, sign in at https://github.com and create a **public** repository named `neon-street-racer`. Do not add a README.
3. In the new repository choose **Add file → Upload files**. Upload the contents of the extracted folder, including `index.html`, `style.css`, `game.js`, `manifest.json`, `sw.js`, and the `icons` folder. Upload files, not the ZIP itself. If folder upload is unavailable, create `icons/icon-192.svg` and `icons/icon-512.svg` via **Add file → Create new file** and paste their contents from this ZIP.
4. Commit the files to the `main` branch.
5. Go to **Settings → Pages**. Under Build and deployment select **Deploy from a branch**, choose `main` and `/ (root)`, then Save.
6. Wait for publishing, then open `https://YOUR-USERNAME.github.io/neon-street-racer/` in Chrome (replace YOUR-USERNAME).
7. Test the game. In Chrome's menu choose **Install app** if shown, or **Add to Home screen**.
8. The installed home-screen app is a PWA, not an APK. This ZIP does not contain an APK and has not built one. If you need an actual `.apk` file, a separate Android packaging/build step is required.
